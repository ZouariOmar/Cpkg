#! /bin/bash

clear
echo Zouari Omar C-Cpp_Package
git clone https://github.com/ZouariOmar/Cpkg.git
echo Happy Coding!
