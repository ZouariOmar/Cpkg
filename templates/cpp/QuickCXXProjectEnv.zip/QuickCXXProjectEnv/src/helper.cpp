//! Lance the Doxygen file comment Her (in NVIM - `SPACE+dh`)

//? Include prototype declaration part
#include "../include/inc.hpp"

//? Function(s) prototype dev part
/*
 * function() {...}
 * class::function() {...}
 */
