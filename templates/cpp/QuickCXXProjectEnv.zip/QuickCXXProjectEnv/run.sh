#! /bin/bash
#* Tape './run.sh' in the main project dir to run your program

#* Compile the main.cpp file, put .exec file in "out" dir and Execute the app
g++ src/main.cpp -o out/app && ./out/app
