//! Lance the Doxygen file comment Her (in NVIM - `SPACE+dh`)

//? Pre-Processor prototype declaration part
#ifndef __INC_HPP__
#define __INC_HPP__

//? Include prototype declaration part

//* Include std headers (c++)
#include <iostream>

//* Use stander c++ workspace
// using namespace std;

//? Structure(s) prototype declaration part
/*
 * struct...
 */

//? Function(s) prototype declaration part
/*
 * func...
 */

//? Class(es) prototype declaration part
/*
 * class...
 */

#endif // __INC_HPP__
