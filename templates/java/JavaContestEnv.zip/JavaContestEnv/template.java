//! Lance the Doxygen file comment Her (doch~)

//? Class(es) prototype dev part
/*
 * function() {...}
 */

//? Main class prototype dev part

/**
 * The Main Program Class
 */
public class template {
  /**
   * The Main Program Function
   *
   * @param args {@code String[]}
   */
  public static void main(String[] args) {

  }
}
