//! Lance the Doxygen file comment Her (in NVIM - `SPACE+d+h`)

/**
 * @class Main
 * @brief Main class
 */
public final class Main {
  /**
   * @fn main(String[])
   * @brief main function
   * @param args {String[]}
   * @return void
   */
  public static void main(String[] args) {
  }
}
