//! Lance the Doxygen file comment Her (in NVIM - `SPACE+dh`)

//? Include prototype declaration part
#include "../include/inc.h"

//? Function(s) prototype dev part
/*
 * function() {...}
 */
