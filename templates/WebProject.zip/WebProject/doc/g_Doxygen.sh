# Generate Doxygen file
doxygen -g