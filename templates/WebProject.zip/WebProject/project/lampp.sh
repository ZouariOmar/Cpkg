#!/usr/bin/bash

# Check if the correct number of arguments is provided
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 {start|stop} {nginx|apache2(httpd)}"
    exit 1
fi

# Start or stop the web server and php-fpm
if [ "$2" == "nginx" || "$2" == "apache2" || "$2" == "httpd" ]; then
    # Start or stop MariaDB, MySQL, web server and php-fpm services
    sudo systemctl "$1" mariadb mysql "$2" php-fpm
    firefox localhost
else
    echo "Error: Unknown web server type: $2"
    exit 1
fi

