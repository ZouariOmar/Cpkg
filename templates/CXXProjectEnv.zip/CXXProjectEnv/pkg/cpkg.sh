#! /bin/bash

clear
echo -e "\033[0;34m@ZouariOmar (zouariomar20@gmail.com)\033[0m"
git clone https://github.com/ZouariOmar/Cpkg.git
echo -e "\033[0;32mHappy Coding!\033[0m"
