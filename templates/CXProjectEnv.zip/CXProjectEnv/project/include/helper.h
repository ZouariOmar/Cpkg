//! Lance the Doxygen file comment Her (in NVIM - `SPACE-dh`)

//? Pre-Processor prototype declaration part
#ifndef __INC_H__
#define __INC_H__

//? Include prototype declaration part

//* Include std c headers
#include <stdio.h>
#include <stdlib.h>

//? Structure prototype declaration part
/*
 * struct...
 */

//? Function prototype declaration part
/*
 * func...
 */

#endif // __INC_H__
