//! Lance the Doxygen file comment Her (in NVIM - `SPACE-dh`)

//? Include prototype declaration part
#include "../include/helper.h"

//? Function prototype dev part
/*
 * function() {...}
 */
