// ! Lance the Doxygen file comment Her (in VSC - `/** */`)

//? Include prototype declaration part
#include "../inc/mainwindow.hpp" // #include "../inc/mainwindow.h"

//? Function/Class prototype dev part
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
  ui->setupUi(this);
}

MainWindow::~MainWindow() {
  delete ui;
}
