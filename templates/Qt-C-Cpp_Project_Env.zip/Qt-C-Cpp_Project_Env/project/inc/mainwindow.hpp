// ! Lance the Doxygen file comment Her (in VSC - `/** */`)

// ? Pre-Processor prototype declaration part
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

// ? Include prototype declaration part
#include "../ui/ui_mainwindow.h"

// * Include std libs (Qt)
#include <qt6/QtCore/QProcess>

// * Include std libs (C++)
#include <iostream>

// * Use stander workspace
using namespace std;

/*
 * Include std libs (c)
 * Include custom inc file (h/hpp)
 */

// ? CLI colors prototype declaration part
/*
 * TEXT COLORS
 ** define COLOR "ANSI CODE"...
 * BACKGROUND COLORS
 ** define bgCOLOR "ANSI CODE"...
 */

// ? Msg prototype declaration part
/*
 * ERROR_MSG
 ** define errorMsgXX...
 * SUCCESS_MSG
 ** define successMsgXX...
 */

// ? Structure prototype declaration part
/*
 * struct...
 */

// ? Class prototype declaration part
QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
  Q_OBJECT

public:
  MainWindow(QWidget *parent = nullptr);
  ~MainWindow();

private:
  Ui::MainWindow *ui;
}; // MainWindow class
#endif // MAINWINDOW_H
