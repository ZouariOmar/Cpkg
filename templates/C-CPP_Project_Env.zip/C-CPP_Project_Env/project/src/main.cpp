//! Lance the Doxygen file comment Her (in NVIM - `SPACE-dh`)

//? Include prototype declaration part
#include "../include/inc.hpp" // #include "./inc/inc.h"

//? Main int function prototype dev part

/**
 * @fn         main(int, const char **)
 * @brief      The Main Program function
 * @param argc int
 * @param argv {const char **}
 * @return int
 */
int main(int argc, const char **argv) {
  std::cout << "Hello World !\n";
  return EXIT_SUCCESS;
}
