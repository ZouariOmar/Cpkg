//! Lance the Doxygen file comment Her (in VSC - `/** */`)

//? Include prototype declaration part
#include "../inc/inc.hpp"  // #include "../inc/inc.h"

//? Function/Class prototype dev part
/*
 * function() {...}
 * class::function() {...}
 */