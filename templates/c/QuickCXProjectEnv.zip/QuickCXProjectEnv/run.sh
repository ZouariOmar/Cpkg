#! /bin/bash
#* Tape './run.sh' in the main project dir to run your program

# Compile the main.c file, put .exec file in "out" dir and execute the app
gcc src/main.c -o out/app && ./out/app
