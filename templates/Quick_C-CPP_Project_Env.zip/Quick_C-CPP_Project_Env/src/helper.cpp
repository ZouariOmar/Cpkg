//! Lance the Doxygen file comment Her (in NVIM - `SPACE+dh`)

//? Include prototype declaration part
#include "../include/inc.hpp" // #include "../include/inc.h"

//? Function(s)/Class(es) prototype dev part
/*
 * function() {...}
 * class::function() {...}
 */
