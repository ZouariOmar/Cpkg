//! Lance the Doxygen file comment Her (in VSC - `/**↵`)

//? Pre-Processor prototype declaration part
#ifndef __INC_HPP__ // Or __INC_H__
#define __INC_HPP__ // Or __INC_H__

//? Include prototype declaration part

//* Include std headers (c++)
#include <iostream>

//* Use stander c++ workspace
// using namespace std;

//* Include std headers (c)
// #include <stdio.h>
// #include <stdlib.h>

//? Structure(s) prototype declaration part
/*
 * struct...
 */

//? Function(s) prototype declaration part
/*
 * func...
 */

//? Class(es) prototype declaration part
/*
 * class...
 */

#endif // __INC_HPP__ Or __INC_H__