//! Lance the Doxygen file comment Her (in VSC - `/** */`)

//? Include prototype declaration part
#include "../inc/inc.hpp"  // #include "../inc/inc.hpp"

//? Function/Class prototype dev part
/*
 * function() {...}
 * class::function() {...}
 */