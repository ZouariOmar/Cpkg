//! Lance the Doxygen file comment Her (in NVIM - `SPACE+d+h`)

//? Include prototype declaration part
#include <iostream>

//? Function(s)/Class(es) prototype dev part
/*
 * function() {...}
 * class::function() {...}
 */

//? Main function prototype dev part

/**
 * @fn         main(void)
 * @brief      The Main Program Function
 * @return     int
 */
int main(void) {
  std::cout << "Hello World !\n";
  return EXIT_SUCCESS;
}
