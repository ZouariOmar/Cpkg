// ! Lance the Doxygen file comment Her (in VSC - `/** */`)

// ? Pre-Processor prototype declaration part
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

// ? Include prototype declaration part
#include "../ui/ui_MainWindow.h"

// * Include std libs (Qt)
#include <qt6/QtWidgets/QtWidgets>

// * Include std libs (C++)
// #include <iostream>

// * Use stander workspace
// using namespace std;

/*
 * Include custom headers (h/hpp)
 */

// ? Structure prototype declaration part
/*
 * struct...
 */

// ? Class prototype declaration part
QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

/**
 * @class MainWindow
 * @brief MainWindow class
 */
class MainWindow : public QMainWindow {
  Q_OBJECT

public:
  MainWindow(QWidget *parent = nullptr);
  ~MainWindow();

private:
  Ui::MainWindow *ui;
}; // MainWindow class

#endif // MAINWINDOW_H
