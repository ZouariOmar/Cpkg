// ! Lance the Doxygen file comment Her (in VSC - `/** */`)

// ? Include prototype declaration part
#include "../inc/MainWindow.hpp" // #include "../inc/mainwindow.h"
#include <qt6/QtWidgets/QApplication>

// ? Main int function prototype dev part

/**
 * @brief # The Main Program Function
 * @param argc int
 * @param argv char const **
 * @return int
 */
int main(int argc, char *argv[]) {
  QApplication app(argc, argv);
  MainWindow w;
  w.show();
  return app.exec();
}
